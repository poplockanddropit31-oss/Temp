package com.example.fakesms

import android.app.Activity
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.IBinder

// Required by Android for the default-SMS-app role. Intentionally do nothing.
class MmsReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }
class ComposeActivity : Activity() { override fun onCreate(b: Bundle?) { super.onCreate(b); finish() } }
class RespondViaMessageService : Service() { override fun onBind(i: Intent?): IBinder? = null }
