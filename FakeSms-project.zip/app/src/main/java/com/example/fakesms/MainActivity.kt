package com.example.fakesms

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.Telephony
import android.view.ViewGroup
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        val scroll = ScrollView(this).apply { addView(root) }

        status = TextView(this)
        val sender = EditText(this).apply { hint = "Sender (name or number)"; setText("Mom") }
        val body = EditText(this).apply { hint = "Message text"; setText("Call me ASAP, it's important") }
        val picker = TimePicker(this)
        val btnDefault = Button(this).apply { text = "1. Make this the default SMS app" }
        val btnSchedule = Button(this).apply { text = "2. Schedule fake text" }

        listOf(status, sender, body, picker, btnDefault, btnSchedule).forEach {
            root.addView(it, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 0)
        }

        btnDefault.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 1)
            } else {
                startActivity(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                    .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName))
            }
        }

        btnSchedule.setOnClickListener {
            val am = getSystemService(AlarmManager::class.java)
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                Toast.makeText(this, "Allow exact alarms, then tap Schedule again", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, picker.hour)
                set(Calendar.MINUTE, picker.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val intent = Intent(this, FireReceiver::class.java)
                .putExtra("sender", sender.text.toString())
                .putExtra("body", body.text.toString())
            val pi = PendingIntent.getBroadcast(
                this, 1, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
            Toast.makeText(this, "Scheduled for ${cal.time}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        val isDefault = Telephony.Sms.getDefaultSmsPackage(this) == packageName
        status.text = if (isDefault) "Default SMS app: YES (inserts will work)"
        else "Default SMS app: NO (notification only, nothing written to the log)"
    }
}
